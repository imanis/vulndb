/*
 var oTable;
 var selected = new Array();


 $(function () {
 $(".load").click(function () {
 $("form").submit();
 alert(selected);
 return false;
 });
 });




 $(document).ready(function () {
 oTable= $('#vulns_table').DataTable();

 $(".nRow").click(function () {
 var iPos = oTable.fnGetPosition(".nRow");
 var aData = oTable.fnGetData(iPos);
 var iId = aData[0];
 if (jQuery.inArray(iId, selected) == -1) {
 selected[selected.length++] = iId;
 }
 else {
 selected = jQuery.grep(selected, function (value) {
 return value != iId;
 });
 }

 $(".nRow").toggleClass('row_selected');
 });
 })



 var s
 $(document).ready(function() {selectedIDs
 var table = $('#vulns_table').DataTable();

 $('#vulns_table tbody').on( 'click', 'tr', function () {
 $(this).toggleClass('selected');
 } );

 $('.load').click( function () {
 var selected = table.cell('.selected',0)

 console.log (selected.data())
 s =  selected
 //alert( table.rows('.selected').data().id() );
 } );
 } );

 */

var oTable;
var selectedIDs = new Array();

$(document).ready(function () {
    /* Add a click handler to the rows - this could be used as a callback */
    $("#vulns_table tbody tr").click(function (e) {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
        }
        else {
            oTable.$('tr.selected')//.removeClass('row_selected');
            $(this).addClass('selected');
        }
    });


    /* Init the table */
    oTable = $('#vulns_table').dataTable();


    /* Get the rows which are currently selected */
    function fnGetSelected(oTableLocal) {
        return oTableLocal.$('tr.selected');
    }


    /* Add a click handler for the delete row */
    $('.load').click(function () {
        var anSelected = fnGetSelected(oTable);
        selectedIDs = new Array();
        $(anSelected).each(function () {
            selectedIDs.push($(this).find("td:first a").html());
        });
        selectedIDs.join(',')
        $("input[name='ids']").val("");
        $("input[name='ids']").val(selectedIDs);

         $("form").submit();
/*
        $.ajax({
            type: "POST",
            url: '/projects/load_submit/',
            dataType: 'json',
            data: {"selected": selectedIDs },
            cache: false,
            type: 'post',
            success: function (data) {
                alert("done")
            }
        });
*/
    });


})

