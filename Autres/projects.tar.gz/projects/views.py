from django.http.response import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden, HttpResponseBadRequest, HttpResponse
from vulnDB.projects.forms import *
from vulnDB.projects.models import *
from vulnDB.vulns.models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from vulnDB.vulns.forms import VulnForm, VulnCategoryForm
from vulnDB.feeds.models import Feed
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required, permission_required
from .chart import ChartData
from vulnDB.decorators import ajax_required
import markdown
import json
from django.template.loader import render_to_string
from eztables.views import DatatablesView
from django.shortcuts import redirect
from django.conf import settings as django_settings
import os
from PIL import Image


@login_required
def _projects(request, projects, active):
    paginator = Paginator(projects, 10)
    page = request.GET.get('page')
    try:
        projects = paginator.page(page)
    except PageNotAnInteger:
        projects = paginator.page(1)
    except EmptyPage:
        projects = paginator.page(paginator.num_pages)
    return render(request, 'projects/projects.html', {'projects': projects, 'active': active})


@login_required
def projects(request):
    return active(request)


@login_required
def active(request):
    projects = Project.get_active()
    return _projects(request, projects, 'active')


@login_required
def archived(request):
    projects = Project.get_archived()
    return _projects(request, projects, 'archived')


@login_required
def all(request):
    projects = Project.objects.all()
    return _projects(request, projects, 'all')


@login_required
def project(request, slug):
    project = get_object_or_404(Project, slug=slug)
    request.session['active_project'] = project.pk
    request.session['active_project_slug'] = slug
    vulns = VulnInst.objects.filter(project=project)
    return render(request, 'projects/project.html', {'project': project, 'vulns': vulns})


@login_required
@permission_required('Projects.add_project')
def start(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = Project()
            project.create_user = request.user
            project.project = form.cleaned_data.get('project')
            project.nature = form.cleaned_data.get('nature')
            project.client = form.cleaned_data.get('client')

            project.status = Project.ACTIVE
            project.teammanager = request.user
            project.save()

            #add all cssv global to project instance
            for i in VulnExploitation_impact.objects.all():
                c=ProjectExploitation_impact(exploitation_impact=i.exploitation_impact,project=project)
                c.save()

            for i in VulnExploitation_complexity.objects.all():
                c=ProjectExploitation_complexity(exploitation_complexity=i.exploitation_complexity,project=project)
                c.save()

            for i in VulnAction_complexity.objects.all():
                c=ProjectAction_complexity(action_complexity=i.action_complexity,project=project)
                c.save()

            for j in VulnSeverity.objects.all():
                c=ProjectSeverity(severity=j.severity,project=project)
                c.save()

            for i in VulnAction_priority.objects.all():
                c=ProjectAction_priority(action_priority=i.action_priority,project=project) 
                c.save()


            for i in VulnSeverityMatrix.objects.all():
                exploitation_impact=ProjectExploitation_impact.objects.get(exploitation_impact=i.exploitation_impact.exploitation_impact,project__id=project.id)
                exploitation_complexity=ProjectExploitation_complexity.objects.get(exploitation_complexity=i.exploitation_complexity.exploitation_complexity,project__id=project.id)
                severity=ProjectSeverity.objects.get(severity=i.severity.severity,project__id=project.id)
                c=ProjectSeverityMatrix(exploitation_impact=exploitation_impact,exploitation_complexity=exploitation_complexity,severity=severity)
                c.save()

            for i in VulnActionPriorityMatrix.objects.all():
                action_complexity=ProjectAction_complexity.objects.get(action_complexity=i.action_complexity.action_complexity,project__id=project.id)
                action_priority=ProjectAction_priority.objects.get(action_priority=i.action_priority.action_priority,project__id=project.id)
                severity=ProjectSeverity.objects.get(severity=i.severity.severity,project__id=project.id)
                c=ProjectActionPriorityMatrix(action_complexity=action_complexity,action_priority=action_priority,severity=severity)
                c.save()


            add_project_post = u'<span class="glyphicon glyphicon-expand"></span> {0} Start a new Project <a href="/projects/{1}>{2}</a> .' \
                .format(request.user, project.slug, project.project)
            feed = Feed(user=request.user, post=add_project_post)
            feed.save()
            # request.user.profile.notify_Adding_vuln(project)

            return redirect('/projects/')
    else:
        form = ProjectForm()
    return render(request, 'projects/start.html', {'form': form})




# project cssv
@login_required
def project_change_serevity(request,serevety_id,project_id):
    if request.method == 'POST':
        form = ChangeServityForm(request.POST,project=project_id)
        if form.is_valid():
            severity_matrix=ProjectSeverityMatrix.objects.get(id=serevety_id)
            severity_matrix.severity=ProjectSeverity.objects.get(id=form.cleaned_data['severity'].id)
            severity_matrix.save()
            update_serevity = u'Update Servety id {0} .'.format(severity_matrix.id)
            feed = Feed(user=request.user, post=update_serevity)
            feed.save()
            return redirect('preferences_project', etat='severity',project_id=project_id)
    
# project cssv
@login_required
def project_change_action(request,action_id,project_id):
    if request.method == 'POST':
        form = ChangeActionForm(request.POST,project=project_id)
        if form.is_valid():
            actino_matrix=ProjectActionPriorityMatrix.objects.get(id=action_id)
            actino_matrix.action_priority=ProjectAction_priority.objects.get(id=form.cleaned_data['action'].id)
            actino_matrix.save()
            update_action = u'Update Priority id {0} .'.format(actino_matrix.id)
            feed = Feed(user=request.user, post=update_action)
            feed.save()
            return redirect('preferences_project', etat='priority',project_id=project_id)
# project cssv
@login_required
def preferences(request, project_id,etat):

    exploitation_complexity=ProjectExploitation_complexity.objects.filter(project__id=project_id)
    exploitation_impact=ProjectExploitation_impact.objects.filter(project__id=project_id)
    action_complexity=ProjectAction_complexity.objects.filter(project__id=project_id)
    severity=ProjectSeverity.objects.filter(project__id=project_id).exclude(severity="Empty")

    formServity = ChangeServityForm(project=project_id)
    formAction = ChangeActionForm(project=project_id)
    return render(request, 'projects/preferences.html', {'project_id':project_id,'etat':etat,'exploitation_impact':exploitation_impact,'exploitation_complexity':exploitation_complexity,\
        'action_complexity':action_complexity,'severity_liste':severity,'formServity':formServity,'formAction':formAction})


@login_required
def modify(request, id):
    if id:
        project = get_object_or_404(Project, pk=id)
        project.update_user = request.user
    else:
        project = Vuln(create_user=request.user)

    if request.POST:
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.save()
            modify_project_post = u'<span class="glyphicon glyphicon-refresh"></span> {0} Modify an existing Project <a href="/projects/{1}>{2}</a> .' \
                .format(request.user, project.slug, project.project)
            feed = Feed(user=request.user, post=modify_project_post)
            feed.save()
            return redirect('/projects/')
    else:
        form = VulnForm(instance=project)
    return render(request, 'project/modify.html', {'form': form})


@login_required
def remove(request, id):
    if id:
        project = get_object_or_404(Project, pk=id)
        if project.create_user == request.user:
            remove_project_post = u'<span class="glyphicon glyphicon-trash"></span> {0} Remove a Project <b> {1}</b> .' \
                .format(request.user, project.project)
            feed = Feed(user=request.user, post=remove_project_post)
            feed.save()
            project.delete()

    return redirect('/projects/')


@login_required
def archive(request, id):
    if id:
        project = get_object_or_404(Project, pk=id)
        if project.create_user == request.user:
            project.status = Project.ARCHIVED
            project.save()
            archive_project_post = u'<span class="glyphicon glyphicon-file"></span> {0} Archive an active Project <a href="/projects/{1}>{2}</a> .' \
                .format(request.user, project.slug, project.project)
            feed = Feed(user=request.user, post=archive_project_post)
            feed.save()
            return redirect('/projects/' + project.slug)
    return redirect('/projects/')


@login_required
def activate(request, id):
    if id:
        project = get_object_or_404(Project, pk=id)
        if project.create_user == request.user:
            project.status = Project.ACTIVE
            project.save()
            active_project_post = u'<span class="glyphicon glyphicon-ok"></span> {0} Activate an archived Project <a href="/projects/{1}>{2}</a> .' \
                .format(request.user, project.slug, project.project)
            feed = Feed(user=request.user, post=active_project_post)
            feed.save()
            return redirect('/projects/' + project.slug)
    return redirect('/projects/')


# # Project Vulns Managment

@login_required
def load(request):
    active_project = request.session.get('active_project', False)

    if active_project:
        if request.method == 'POST':
            form = VulnSelectionForm(request.POST)
            project = get_object_or_404(Project, pk=active_project)
            if form.is_valid():
                ids = form.cleaned_data.get('ids').split(',')
                for id_v in ids:
                    vuln = get_object_or_404(Vuln, pk=id_v)
                    vulninst = VulnInst(base_pk=id_v)
                    vulninst.instanciate(vuln)
                    vulninst.project = project

                    vulninst.pk = None
                    vulninst.exploitation_impact=ProjectExploitation_impact.objects.get(project_id=project.id,exploitation_impact=vuln.exploitation_impact.exploitation_impact)
                    vulninst.exploitation_complexity=ProjectExploitation_complexity.objects.get(project_id=project.id,exploitation_complexity=vuln.exploitation_complexity.exploitation_complexity)
                    vulninst.action_complexity=ProjectAction_complexity.objects.get(project_id=project.id,action_complexity=vuln.action_complexity.action_complexity)
                    
                    vulninst.save()
                        

                    v=VulnInst.objects.get(pk=vulninst.pk)
                    for tag in vuln.tags.all():
                        taginst, created=TagProject.objects.get_or_create(name=tag.name)
                        
                        taginst.save()
                        v.tags.add(taginst)
                    v.save()
                    
                    vulninst = VulnInst.objects.filter(pk=vulninst.pk).first()
                    loding_vuln_post = u'<span class="glyphicon glyphicon-fire"></span> {0} Load a new Vulnerability <a href="/projects/show/{1}/">{2}</a> to Project <a href="/projects/{3}/">{4}</a> .' \
                        .format(request.user, vulninst.pk, vulninst.vulnerability, project.slug, project.project)
                    feed = Feed(user=request.user, post=loding_vuln_post)
                    feed.save()
                    request.user.profile.notify_Adding_vulnInst(vulninst, project)
            else:
                if form.data.__contains__('vref'):
                    vref = form.data.get('vref')
                    
                    vref = float(vref)
                    vuln = get_object_or_404(Vuln, pk=vref)
                    vulninst = VulnInst()
                    vulninst.base_pk = vref
                    vulninst.instanciate(vuln)
                    vulninst.project = project
                    vulninst.exploitation_impact=ProjectExploitation_impact.objects.get(project_id=project.id,exploitation_impact=vuln.exploitation_impact.exploitation_impact)
                    vulninst.exploitation_complexity=ProjectExploitation_complexity.objects.get(project_id=project.id,exploitation_complexity=vuln.exploitation_complexity.exploitation_complexity)
                    vulninst.action_complexity=ProjectAction_complexity.objects.get(project_id=project.id,action_complexity=vuln.action_complexity.action_complexity)                 
                    vulninst.save()
                        
                    #add tags
                    v=VulnInst.objects.get(pk=vulninst.pk)
                    for tag in vuln.tags.all():
                        taginst, created=TagProject.objects.get_or_create(name=tag.name)
                        
                    v.tags.add(taginst)
                    v.save()
                        
            
            if project:
                return redirect('/projects/' + project.slug)
            else:
                return redirect('/projects')
        else:
            project = active_project
            all_vulns = Vuln.get_published()
            form = VulnSelectionForm()
            return render(request, 'projects/vulns_selection.html',
                          {'vulns': all_vulns, 'project': project, 'form': form})

    else:
        return redirect('/projects/')


@login_required
def show_vuln(request, pk):
        vuln = get_object_or_404(VulnInst, pk=pk)
        active_project = request.session.get('active_project', False)
        project=get_object_or_404(Project,pk=active_project)
        return render(request, 'projects/vuln.html', {'vuln': vuln,'project':project})


@login_required
def edit(request, id):
    if id:
        vuln = get_object_or_404(VulnInst, pk=id)
        vuln.update_user = request.user
        active_project = request.session.get('active_project', False)
        active_project_slug = request.session.get('active_project_slug', False)
        project=get_object_or_404(Project,pk=active_project)

    else:
        vuln = VulnInst(create_user=request.user)

    if request.POST:
        form = ProjectVulnForm(request.POST, instance=vuln,project=project.id)
        if form.is_valid():
            vuln.vulnerability = form.cleaned_data.get('vulnerability')
            vuln.description = form.cleaned_data.get('description')
            vuln.recommendation = form.cleaned_data.get('recommendation')
            # vuln.severity = form.cleaned_data.get('severity')
            vuln.type = form.cleaned_data.get('type')
            vuln.nature = form.cleaned_data.get('nature')
            vuln.category = form.cleaned_data.get('category')
            vuln.exploitation_impact = form.cleaned_data.get('exploitation_impact')
            vuln.exploitation_complexity = form.cleaned_data.get('exploitation_complexity')
            vuln.action_complexity = form.cleaned_data.get('action_complexity')
            vuln.action_priority = form.cleaned_data.get('action_priority')



           

            # add tags
            vuln.tags.through.objects.filter(vulninst__id=vuln.id).delete()
            tags = form.cleaned_data.get('tags')
            vuln.create_tags(tags)
            vuln.save()
            edit_p_vuln_post = u'{0} <span class="glyphicon glyphicon-refresh"></span> Edit a Vulnerability <a href="/vulns/{1}/">{2}</a> from Project <a href="/projects/{3}/">{4}</a> .' \
                .format(request.user, vuln.slug, vuln.vulnerability, project.slug, project.project)
            feed = Feed(user=request.user, post=edit_p_vuln_post)
            feed.save()
            return redirect('/projects/' + active_project_slug)

    else:
        form = ProjectVulnForm(project=project.id, instance=vuln)

    tagsliste= vuln.get_items_tags()
    tags = [i.name for i in Tag.objects.all()]
    return render(request, 'projects/edit.html', {'tags':tags,'tagsliste':tagsliste,'form': form, 'project':project})


@login_required
def delete(request, id):
    if id:
        vuln = get_object_or_404(VulnInst, pk=id)
        active_project = request.session.get('active_project', False)
        active_project_slug = request.session.get('active_project_slug', False)
        project=get_object_or_404(Project,pk=active_project)
        if vuln.project.pk == active_project:
            delete_p_vuln_post = u' <span class="glyphicon glyphicon-trash"></span> {0} Remove a Vulnerability <b>{1}</b> from Project <a href="/projects/{2}/">{3}</a> .' \
                .format(request.user, vuln.vulnerability, project.slug, project.project)
            feed = Feed(user=request.user, post=delete_p_vuln_post)
            feed.save()
            vuln.delete()
    return redirect('/projects/' + active_project_slug)


@login_required
def add_client(request):
    data = {}
    if request.method == 'POST':  # and request.is_ajax():
        form = ClientForm(request.POST)
        if form.is_valid():
            client = Client()
            client.name = form.cleaned_data.get('name')
            client.save()
            add_client_post = u'{0} <span class="glyphicon glyphicon-trash"></span> Add a new Client <b>{1}</b> .' \
                .format(request.user, client.name)
            feed = Feed(user=request.user, post=add_client_post)
            feed.save()
            data['new_item_value'] = client.name;
            data['new_item_key'] = client.pk;
            data['stat'] = "ok";
            return HttpResponse(json.dumps(data), mimetype="application/json")
        else:
            data['stat'] = "error";
            return render(request, 'projects/add_client_modal.html', {'form': form})
    else:
        form = ClientForm()
        return render(request, 'projects/add_client_modal.html', {'form': form})


@login_required
def chart_data_json(request):
    data = {}
    params = request.GET

    days = ''
    name = params.get('name', '')
    active_project = request.session.get('active_project', False)

    if name == 'dst_by_severity':
        data['chart_data'] = ChartData.get_dst_by_severity(active_project)


    elif name == 'dst_by_type':
        data['chart_data'] = ChartData.get_dst_by_type(active_project)

    elif name == 'dst_by_action_prio':
        data['chart_data'] = ChartData.get_dst_by_AP(active_project)

    elif name == 'dst_by_action_compl':
        data['chart_data'] = ChartData.get_dst_by_AC(active_project)

    return HttpResponse(json.dumps(data), content_type='application/json')


@login_required
def client(request, id):
    if id:
        client = get_object_or_404(Client, pk=id)
        request.session['active_client'] = client.pk
        projects = Project.objects.filter(client=client)
        uploaded_picture = False
        try:
            if request.GET.get('upload_picture') == 'uploaded':
                uploaded_picture = True
        except Exception, e:
            pass

        return render(request, 'projects/client.html',
                      {'client_projects': projects, 'client': client, 'uploaded_picture': uploaded_picture})

    return redirect('/projects')


@login_required
def c_upload_picture(request):
    try:
        active_client = request.session.get('active_client', False)
        profile_pictures = django_settings.MEDIA_ROOT + '/client_pictures/'
        if not os.path.exists(profile_pictures):
            os.makedirs(profile_pictures)
        f = request.FILES['picture']
        filename = profile_pictures + str(active_client) + '_tmp.jpg'
        with open(filename, 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)
        im = Image.open(filename)
        width, height = im.size
        if width > 350:
            new_width = 350
            new_height = (height * 350) / width
            new_size = new_width, new_height
            im.thumbnail(new_size, Image.ANTIALIAS)
            im.save(filename)
        return redirect('/projects/client/{0}/?upload_picture=uploaded'.format(active_client))
    except Exception, e:
        try:
            return redirect('/projects/client/{0}/'.format(active_client))
        except Exception, e:
            return redirect('/projects')


@login_required
def c_save_uploaded_picture(request):
    try:
        active_client = request.session.get('active_client', False)

        x = int(request.POST.get('x'))
        y = int(request.POST.get('y'))
        w = int(request.POST.get('w'))
        h = int(request.POST.get('h'))
        tmp_filename = django_settings.MEDIA_ROOT + '/client_pictures/{0}_tmp.jpg'.format(active_client)
        filename = django_settings.MEDIA_ROOT + '/client_pictures/{0}.jpg'.format(active_client)
        im = Image.open(tmp_filename)
        cropped_im = im.crop((x, y, w + x, h + y))
        cropped_im.thumbnail((200, 200), Image.ANTIALIAS)
        cropped_im.save(filename)
        os.remove(tmp_filename)
        return redirect('/projects/client/{0}/'.format(active_client))
    except Exception, e:
        pass
    return redirect('/projects/')