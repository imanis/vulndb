from django.contrib import admin
from vulnDB.projects.models import Project, VulnInst, Client, ProjectNature

admin.site.register(Project)
admin.site.register(VulnInst)
admin.site.register(Client)

admin.site.register(ProjectNature)



